set ModuleHierarchy {[{
"Name" : "cortex_m0_top", "RefName" : "cortex_m0_top","ID" : "0","Type" : "sequential",
"SubInsts" : [
	{"Name" : "grp_cortex_m0_top_Pipeline_VITIS_LOOP_5_1_fu_2425", "RefName" : "cortex_m0_top_Pipeline_VITIS_LOOP_5_1","ID" : "1","Type" : "sequential",
		"SubLoops" : [
		{"Name" : "VITIS_LOOP_5_1","RefName" : "VITIS_LOOP_5_1","ID" : "2","Type" : "pipeline"},]},
	{"Name" : "grp_execute_fu_2431", "RefName" : "execute","ID" : "3","Type" : "sequential",
		"SubInsts" : [
		{"Name" : "call_ln269_regfile_update_flags_fu_1017", "RefName" : "regfile_update_flags","ID" : "4","Type" : "sequential"},
		{"Name" : "call_ln262_regfile_update_flags_fu_1044", "RefName" : "regfile_update_flags","ID" : "5","Type" : "sequential"},
		{"Name" : "call_ln255_regfile_update_flags_fu_1055", "RefName" : "regfile_update_flags","ID" : "6","Type" : "sequential"},
		{"Name" : "call_ln250_regfile_update_flags_fu_1074", "RefName" : "regfile_update_flags","ID" : "7","Type" : "sequential"},
		{"Name" : "call_ln239_regfile_update_flags_fu_1085", "RefName" : "regfile_update_flags","ID" : "8","Type" : "sequential"},
		{"Name" : "call_ln232_regfile_update_flags_fu_1096", "RefName" : "regfile_update_flags","ID" : "9","Type" : "sequential"},
		{"Name" : "call_ln224_regfile_update_flags_fu_1137", "RefName" : "regfile_update_flags","ID" : "10","Type" : "sequential"},
		{"Name" : "call_ln148_regfile_update_flags_fu_1352", "RefName" : "regfile_update_flags","ID" : "11","Type" : "sequential"},
		{"Name" : "call_ln136_regfile_update_flags_fu_1363", "RefName" : "regfile_update_flags","ID" : "12","Type" : "sequential"},
		{"Name" : "call_ln130_regfile_update_flags_fu_1425", "RefName" : "regfile_update_flags","ID" : "13","Type" : "sequential"},
		{"Name" : "call_ln123_regfile_update_flags_fu_1436", "RefName" : "regfile_update_flags","ID" : "14","Type" : "sequential"},
		{"Name" : "call_ln116_regfile_update_flags_fu_1447", "RefName" : "regfile_update_flags","ID" : "15","Type" : "sequential"},
		{"Name" : "call_ln109_regfile_update_flags_fu_1458", "RefName" : "regfile_update_flags","ID" : "16","Type" : "sequential"},
		{"Name" : "call_ln102_regfile_update_flags_fu_1469", "RefName" : "regfile_update_flags","ID" : "17","Type" : "sequential"},
		{"Name" : "call_ln91_regfile_update_flags_fu_1480", "RefName" : "regfile_update_flags","ID" : "18","Type" : "sequential"},
		{"Name" : "call_ln81_regfile_update_flags_fu_1555", "RefName" : "regfile_update_flags","ID" : "19","Type" : "sequential"},
		{"Name" : "call_ln65_regfile_update_flags_fu_1587", "RefName" : "regfile_update_flags","ID" : "20","Type" : "sequential"},
		{"Name" : "call_ln48_regfile_update_flags_fu_1651", "RefName" : "regfile_update_flags","ID" : "21","Type" : "sequential"},
		{"Name" : "call_ln29_regfile_update_flags_fu_1704", "RefName" : "regfile_update_flags","ID" : "22","Type" : "sequential"},]},
	{"Name" : "grp_decode_thumb16_instruction_fu_2446", "RefName" : "decode_thumb16_instruction","ID" : "23","Type" : "sequential",
		"SubInsts" : [
		{"Name" : "grp_extract_bits_fu_1106", "RefName" : "extract_bits","ID" : "24","Type" : "sequential"},
		{"Name" : "grp_extract_bits_fu_1116", "RefName" : "extract_bits","ID" : "25","Type" : "sequential"},
		{"Name" : "grp_extract_bits_fu_1126", "RefName" : "extract_bits","ID" : "26","Type" : "sequential"},
		{"Name" : "grp_extract_bits_fu_1136", "RefName" : "extract_bits","ID" : "27","Type" : "sequential"},
		{"Name" : "grp_extract_bits_fu_1146", "RefName" : "extract_bits","ID" : "28","Type" : "sequential"},]},
	{"Name" : "grp_cortex_m0_top_Pipeline_VITIS_LOOP_665_1_fu_2451", "RefName" : "cortex_m0_top_Pipeline_VITIS_LOOP_665_1","ID" : "29","Type" : "sequential",
		"SubLoops" : [
		{"Name" : "VITIS_LOOP_665_1","RefName" : "VITIS_LOOP_665_1","ID" : "30","Type" : "pipeline"},]},
	{"Name" : "grp_cortex_m0_top_Pipeline_VITIS_LOOP_674_2_fu_2460", "RefName" : "cortex_m0_top_Pipeline_VITIS_LOOP_674_2","ID" : "31","Type" : "sequential",
		"SubLoops" : [
		{"Name" : "VITIS_LOOP_674_2","RefName" : "VITIS_LOOP_674_2","ID" : "32","Type" : "pipeline"},]},]
}]}