dict set slaves CTRL_BUS {ports {reset {type i_ap_none width 32}} mems {} has_ctrl 0}
set datawidth 32
set addrwidth 64
set intr_clr_mode TOW
